const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { authMiddleware, adminOnly } = require('../middleware/auth');

// GET /api/promotions - Obtener promociones activas (público para POS/catálogo)
router.get('/', async (req, res) => {
  try {
    const { branch_id, active_only } = req.query;
    let query = `
      SELECT p.*, c.name as category_name, pr.name as product_name 
      FROM promotions p 
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN products pr ON p.product_id = pr.id
      WHERE 1=1
    `;
    const params = [];

    if (active_only === 'true' || active_only === undefined) {
      query += ` AND p.is_active = 1 AND p.start_date <= NOW() AND p.end_date >= NOW()`;
    }
    if (branch_id) {
      query += ` AND (p.branch_id IS NULL OR p.branch_id = ?)`;
      params.push(parseInt(branch_id));
    }

    query += ` ORDER BY p.created_at DESC`;
    const [promotions] = await pool.query(query, params);
    res.json(promotions);
  } catch (error) {
    console.error('Get promotions error:', error);
    res.status(500).json({ error: 'Error al obtener promociones' });
  }
});

// GET /api/promotions/for-product/:productId - Obtener la mejor promoción para un producto
router.get('/for-product/:productId', async (req, res) => {
  try {
    const { branch_id } = req.query;
    const productId = req.params.productId;

    // Obtener info del producto
    const [products] = await pool.query('SELECT id, category_id, price FROM products WHERE id = ?', [productId]);
    if (products.length === 0) return res.json(null);
    const product = products[0];

    // Buscar promociones aplicables (producto específico, categoría, o todos)
    const [promos] = await pool.query(`
      SELECT * FROM promotions 
      WHERE is_active = 1 AND start_date <= NOW() AND end_date >= NOW()
      AND (
        (applies_to = 'product' AND product_id = ?)
        OR (applies_to = 'category' AND category_id = ?)
        OR applies_to = 'all'
      )
      AND (branch_id IS NULL OR branch_id = ?)
      ORDER BY discount_value DESC
      LIMIT 1
    `, [productId, product.category_id, branch_id || 1]);

    if (promos.length === 0) return res.json(null);
    
    const promo = promos[0];
    let discountedPrice = product.price;
    if (promo.discount_type === 'percentage') {
      discountedPrice = product.price * (1 - promo.discount_value / 100);
    } else {
      discountedPrice = Math.max(0, product.price - promo.discount_value);
    }

    res.json({
      ...promo,
      original_price: product.price,
      discounted_price: parseFloat(discountedPrice.toFixed(2))
    });
  } catch (error) {
    console.error('Get promotion for product error:', error);
    res.status(500).json({ error: 'Error al obtener promoción' });
  }
});

// POST /api/promotions
router.post('/', authMiddleware, adminOnly, async (req, res) => {
  try {
    const { name, description, discount_type, discount_value, applies_to, category_id, product_id, start_date, end_date, branch_id } = req.body;
    if (!name || !discount_value || !start_date || !end_date) {
      return res.status(400).json({ error: 'Nombre, descuento, fecha inicio y fecha fin son requeridos' });
    }

    const [result] = await pool.query(
      `INSERT INTO promotions (name, description, discount_type, discount_value, applies_to, category_id, product_id, start_date, end_date, is_active, branch_id) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
      [name, description || '', discount_type || 'percentage', discount_value, applies_to || 'all', 
       category_id || null, product_id || null, start_date, end_date, branch_id || null]
    );

    const [newPromo] = await pool.query('SELECT * FROM promotions WHERE id = ?', [result.insertId]);
    res.status(201).json(newPromo[0]);
  } catch (error) {
    console.error('Create promotion error:', error);
    res.status(500).json({ error: 'Error al crear promoción' });
  }
});

// PUT /api/promotions/:id
router.put('/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    const { name, description, discount_type, discount_value, applies_to, category_id, product_id, start_date, end_date, is_active, branch_id } = req.body;
    
    await pool.query(
      `UPDATE promotions SET name = ?, description = ?, discount_type = ?, discount_value = ?, 
       applies_to = ?, category_id = ?, product_id = ?, start_date = ?, end_date = ?, is_active = ?, branch_id = ? WHERE id = ?`,
      [name, description, discount_type, discount_value, applies_to, 
       category_id || null, product_id || null, start_date, end_date, is_active ? 1 : 0, branch_id || null, req.params.id]
    );

    res.json({ message: 'Promoción actualizada' });
  } catch (error) {
    console.error('Update promotion error:', error);
    res.status(500).json({ error: 'Error al actualizar promoción' });
  }
});

// DELETE /api/promotions/:id
router.delete('/:id', authMiddleware, adminOnly, async (req, res) => {
  try {
    await pool.query('DELETE FROM promotions WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    console.error('Delete promotion error:', error);
    res.status(500).json({ error: 'Error al eliminar promoción' });
  }
});

module.exports = router;
