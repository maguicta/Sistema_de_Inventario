# Sistema de Control de Inventario y Ventas

Sistema web para gestión de inventario, ventas (POS), clientes, proveedores y reportes con soporte multi-sucursal.

## Requisitos

- **Node.js** v18 o superior
- **MySQL** 5.7 o superior (XAMPP, WampServer, o MySQL Server)
- **Navegador** moderno (Chrome, Firefox, Edge)

## Instalación Rápida

1. Instalar **Node.js** desde https://nodejs.org
2. Encender **MySQL** (XAMPP o WampServer)
3. Hacer **doble clic en `setup.bat`**
4. Completar el formulario con los datos de MySQL y las credenciales del administrador
5. Se creará un acceso directo en el escritorio

## Iniciar el Sistema

- Hacer doble clic en `iniciar_sistema.bat`
- O ejecutar `npm start` en la terminal

## Estructura del Proyecto

```
inventory-system/
├── config/database.js      # Conexión a MySQL
├── database/
│   ├── schema.sql          # Esquema de tablas
│   ├── init.js             # Script de inicialización
│   ├── check_connection.js # Verificador de conexión
│   └── reset_admin.js      # Resetear contraseña admin
├── middleware/auth.js      # Middleware de autenticación JWT
├── public/
│   ├── index.html          # Página principal (SPA)
│   ├── catalog.html        # Catálogo público
│   ├── css/styles.css      # Estilos
│   └── js/app.js           # Frontend completo
├── routes/                 # API routes
├── server.js               # Servidor Express
├── package.json            # Dependencias NPM
├── .env                    # Variables de entorno
├── setup.bat               # Instalador
├── iniciar_sistema.bat     # Lanzador Windows
└── MANUAL_DE_USO.md        # Manual de usuario
```

## Scripts Útiles

| Comando | Descripción |
|---------|-------------|
| `npm start` | Iniciar el servidor |
| `npm run db:init` | Crear/inicializar base de datos |
| `node database/reset_admin.js` | Resetear contraseña del admin |
| `node database/check_connection.js` | Verificar conexión a MySQL |
