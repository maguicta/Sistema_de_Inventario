@echo off
title Instalador - Sistema de Inventario
cd /d "%~dp0"

echo ========================================================
echo       INSTALADOR DEL SISTEMA DE INVENTARIO Y VENTAS
echo ========================================================
echo.

REM Verificar si PowerShell está disponible
where powershell >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] PowerShell no esta disponible en este sistema.
    pause
    exit /b
)

REM Verificar si Node.js está instalado
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js no esta instalado.
    echo Por favor, descargue e instale Node.js desde: https://nodejs.org
    echo (Seleccione la version LTS y marque "Add to PATH" durante la instalacion)
    pause
    exit /b
)

echo [INFO] Node.js detectado correctamente.
echo [INFO] Abriendo asistente de instalacion...
echo.

REM Ejecutar el instalador PowerShell con política de ejecución bypass
powershell.exe -ExecutionPolicy Bypass -File "%~dp0Installer.ps1"

if %errorlevel% neq 0 (
    echo.
    echo [INFO] El asistente se cerro o hubo un error.
    pause
)
