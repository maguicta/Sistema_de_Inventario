const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

// GET /api/returns
// Obtiene el historial de devoluciones
router.get('/', async (req, res) => {
  try {
    const branch_id = req.user.branch_id || 1;
    const [returns] = await pool.query(`
      SELECT r.*, u.name as user_name, s.invoice_number 
      FROM \`returns\` r
      LEFT JOIN users u ON r.user_id = u.id
      LEFT JOIN sales s ON r.sale_id = s.id
      WHERE r.branch_id = ?
      ORDER BY r.created_at DESC
    `, [branch_id]);
    res.json(returns);
  } catch (error) {
    console.error('Error fetching returns:', error);
    res.status(500).json({ error: 'Error al obtener devoluciones' });
  }
});

// GET /api/returns/:id
// Obtiene el detalle de una devolución
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const branch_id = req.user.branch_id || 1;
    
    const [returns] = await pool.query(`
      SELECT r.*, u.name as user_name, s.invoice_number 
      FROM \`returns\` r
      LEFT JOIN users u ON r.user_id = u.id
      LEFT JOIN sales s ON r.sale_id = s.id
      WHERE r.id = ? AND r.branch_id = ?
    `, [id, branch_id]);

    if (returns.length === 0) {
      return res.status(404).json({ error: 'Devolución no encontrada' });
    }

    const [items] = await pool.query('SELECT * FROM return_items WHERE return_id = ?', [id]);
    
    res.json({ ...returns[0], items });
  } catch (error) {
    console.error('Error fetching return detail:', error);
    res.status(500).json({ error: 'Error al obtener detalle de la devolución' });
  }
});

// POST /api/returns
// Registra una nueva devolución
router.post('/', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const { sale_id, items, reason } = req.body;
    const branch_id = req.user.branch_id || 1;
    const user_id = req.user.id;

    if (!sale_id || !items || items.length === 0) {
      return res.status(400).json({ error: 'Datos inválidos para la devolución' });
    }

    // Verificar permisos
    if (req.user.role === 'vendedor') {
      const [settings] = await conn.query('SELECT setting_value FROM settings WHERE setting_key = "allow_seller_returns"');
      const allowSellerReturns = settings.length > 0 && settings[0].setting_value === 'true';
      if (!allowSellerReturns) {
        throw new Error('No tienes permiso para procesar devoluciones');
      }
    }

    // Validar venta
    const [sales] = await conn.query('SELECT * FROM sales WHERE id = ? AND branch_id = ?', [sale_id, branch_id]);
    if (sales.length === 0) throw new Error('Venta no encontrada');

    // Generar número de devolución
    const now = new Date();
    const dateStr = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
    const [countResult] = await conn.query(
      `SELECT COUNT(*) as count FROM \`returns\` WHERE DATE(created_at) = CURDATE() AND branch_id = ?`, [branch_id]
    );
    const returnNum = `DEV-${dateStr}-${String(countResult[0].count + 1).padStart(3, '0')}`;

    let totalAmount = 0;

    // Crear la cabecera de la devolución
    const [returnResult] = await conn.query(`
      INSERT INTO \`returns\` (return_number, sale_id, user_id, branch_id, reason, total_amount)
      VALUES (?, ?, ?, ?, ?, 0)
    `, [returnNum, sale_id, user_id, branch_id, reason || '']);

    const returnId = returnResult.insertId;

    for (const item of items) {
      if (!item.quantity || item.quantity <= 0) continue;

      // Obtener el item de la venta original para validar precios y cantidades
      const [saleItems] = await conn.query('SELECT * FROM sale_items WHERE id = ? AND sale_id = ?', [item.sale_item_id, sale_id]);
      if (saleItems.length === 0) throw new Error(`Item de venta ${item.sale_item_id} no encontrado`);
      const saleItem = saleItems[0];

      if (item.quantity > saleItem.quantity) {
        throw new Error(`No puedes devolver más cantidad de la comprada para ${saleItem.product_name}`);
      }

      const subtotal = item.quantity * saleItem.unit_price;
      totalAmount += subtotal;

      // Registrar item devuelto
      await conn.query(`
        INSERT INTO return_items (return_id, sale_item_id, product_id, product_name, quantity, unit_price, subtotal, restocked)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `, [returnId, saleItem.id, saleItem.product_id, saleItem.product_name, item.quantity, saleItem.unit_price, subtotal, item.restock ? 1 : 0]);

      // Reintegrar stock al inventario si aplica (solo si el checkbox de restock fue marcado)
      if (saleItem.product_id && item.restock) {
        const [products] = await conn.query('SELECT stock FROM products WHERE id = ?', [saleItem.product_id]);
        if (products.length > 0) {
          const currentStock = products[0].stock;
          const newStock = currentStock + item.quantity;
          
          await conn.query('UPDATE products SET stock = ? WHERE id = ?', [newStock, saleItem.product_id]);
          
          // Registrar movimiento de inventario
          await conn.query(`
            INSERT INTO inventory_movements (product_id, type, quantity, previous_stock, new_stock, reference_id, notes, user_id)
            VALUES (?, 'devolucion', ?, ?, ?, ?, ?, ?)
          `, [saleItem.product_id, item.quantity, currentStock, newStock, returnId, `Devolución ${returnNum}`, user_id]);
        }
      }

      // Actualizar el ítem de la factura original para descontar la devolución
      await conn.query('UPDATE sale_items SET quantity = quantity - ?, subtotal = subtotal - ? WHERE id = ?', [item.quantity, subtotal, saleItem.id]);
    }

    // Actualizar el monto total de la devolución
    await conn.query('UPDATE `returns` SET total_amount = ? WHERE id = ?', [totalAmount, returnId]);

    // Descontar la devolución del total de la factura original
    await conn.query('UPDATE sales SET subtotal = subtotal - ?, total = total - ?, amount_paid = GREATEST(0, amount_paid - ?) WHERE id = ?', [totalAmount, totalAmount, totalAmount, sale_id]);

    await conn.commit();
    res.json({ message: 'Devolución procesada con éxito', return_id: returnId });

  } catch (error) {
    await conn.rollback();
    console.error('Error processing return:', error);
    res.status(500).json({ error: error.message || 'Error al procesar la devolución' });
  } finally {
    conn.release();
  }
});

// DELETE /api/returns/:id
// Elimina una devolución y revierte sus efectos
router.delete('/:id', async (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Solo los administradores pueden eliminar devoluciones' });
  }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const { id } = req.params;
    const { revert } = req.query;
    const branch_id = req.user.branch_id || 1;

    // Obtener la devolución
    const [returns] = await conn.query('SELECT * FROM `returns` WHERE id = ? AND branch_id = ?', [id, branch_id]);
    if (returns.length === 0) throw new Error('Devolución no encontrada');
    const ret = returns[0];

    if (revert === 'true') {
      // Obtener items devueltos
      const [items] = await conn.query('SELECT * FROM return_items WHERE return_id = ?', [id]);

      // Revertir items de venta y stock
      for (const item of items) {
        if (item.sale_item_id) {
          // Re-añadir a la factura original
          await conn.query('UPDATE sale_items SET quantity = quantity + ?, subtotal = subtotal + ? WHERE id = ?', [item.quantity, item.subtotal, item.sale_item_id]);
        }
        
        // Revertir stock si se había reintegrado
        if (item.product_id && item.restocked) {
          const [products] = await conn.query('SELECT stock FROM products WHERE id = ?', [item.product_id]);
          if (products.length > 0) {
            const currentStock = products[0].stock;
            const newStock = currentStock - item.quantity;
            await conn.query('UPDATE products SET stock = ? WHERE id = ?', [newStock, item.product_id]);
            
            await conn.query(`
              INSERT INTO inventory_movements (product_id, type, quantity, previous_stock, new_stock, reference_id, notes, user_id)
              VALUES (?, 'ajuste', ?, ?, ?, ?, ?, ?)
            `, [item.product_id, -item.quantity, currentStock, newStock, id, `Reversión de devolución ${ret.return_number}`, req.user.id]);
          }
        }
      }

      // Revertir total de la factura
      await conn.query('UPDATE sales SET subtotal = subtotal + ?, total = total + ?, amount_paid = amount_paid + ? WHERE id = ?', [ret.total_amount, ret.total_amount, ret.total_amount, ret.sale_id]);
    }

    // Eliminar la devolución (cascade eliminará return_items)
    await conn.query('DELETE FROM `returns` WHERE id = ?', [id]);

    await conn.commit();
    res.json({ message: 'Devolución eliminada y revertida correctamente' });
  } catch (error) {
    await conn.rollback();
    console.error('Error deleting return:', error);
    res.status(500).json({ error: error.message || 'Error al eliminar la devolución' });
  } finally {
    conn.release();
  }
});

module.exports = router;
