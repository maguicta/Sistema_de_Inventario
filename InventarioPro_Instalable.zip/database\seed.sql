-- ============================================
-- INVENTARIO PRO - Datos Iniciales
-- NOTA: La inicialización se maneja en init.js
-- Este archivo es solo de referencia.
-- ============================================

SET NAMES utf8mb4;

-- Sucursal por defecto
INSERT INTO `branches` (`id`, `name`) VALUES 
(1, 'Sucursal Principal')
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- Configuración inicial del sistema
INSERT INTO `settings` (`setting_key`, `setting_value`) VALUES
('store_name', 'Inventario Pro'),
('theme', 'midnight'),
('currency_base', 'DOP'),
('currency_symbol', 'RD$'),
('currency_secondary', 'USD'),
('exchange_rate', '1.0000'),
('tax_rate', '18.00'),
('exchange_refresh_interval', '0'),
('allow_negative_stock', 'false')
ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`);
