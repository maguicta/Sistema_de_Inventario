-- ============================================
-- MIGRATION: Agregar precio USD y tabla de promociones
-- Ejecutar en el servidor de producción
-- Fecha: 2026-04-23
-- ============================================

-- Agregar columna price_usd a productos (si no existe)
ALTER TABLE `products` ADD COLUMN IF NOT EXISTS `price_usd` DECIMAL(12,2) DEFAULT NULL AFTER `cost`;

-- Crear tabla de promociones
CREATE TABLE IF NOT EXISTS `promotions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(200) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `discount_type` ENUM('percentage', 'fixed') NOT NULL DEFAULT 'percentage',
  `discount_value` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `applies_to` ENUM('all', 'category', 'product') NOT NULL DEFAULT 'all',
  `category_id` INT DEFAULT NULL,
  `product_id` INT DEFAULT NULL,
  `start_date` DATETIME NOT NULL,
  `end_date` DATETIME NOT NULL,
  `is_active` TINYINT(1) DEFAULT 1,
  `branch_id` INT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_promo_dates` (`start_date`, `end_date`),
  INDEX `idx_promo_active` (`is_active`),
  INDEX `idx_promo_branch` (`branch_id`),
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
