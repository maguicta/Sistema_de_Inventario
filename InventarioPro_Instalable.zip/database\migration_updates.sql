-- ============================================
-- ACTUALIZACIÓN: DEVOLUCIONES Y FIADOS
-- ============================================

SET FOREIGN_KEY_CHECKS = 0;

-- 1. PAGOS DE VENTAS (Abonos para fiados)
CREATE TABLE IF NOT EXISTS `sale_payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `sale_id` INT NOT NULL,
  `user_id` INT DEFAULT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `payment_method` VARCHAR(30) DEFAULT 'efectivo',
  `branch_id` INT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_sale_payments_sale` (`sale_id`),
  INDEX `idx_sale_payments_branch` (`branch_id`),
  FOREIGN KEY (`sale_id`) REFERENCES `sales`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. DEVOLUCIONES (returns)
CREATE TABLE IF NOT EXISTS `returns` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `return_number` VARCHAR(50) NOT NULL,
  `sale_id` INT NOT NULL,
  `user_id` INT DEFAULT NULL,
  `branch_id` INT DEFAULT 1,
  `total_amount` DECIMAL(12,2) DEFAULT 0.00,
  `reason` TEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_returns_sale` (`sale_id`),
  INDEX `idx_returns_branch` (`branch_id`),
  FOREIGN KEY (`sale_id`) REFERENCES `sales`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. ITEMS DEVUELTOS (return_items)
CREATE TABLE IF NOT EXISTS `return_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `return_id` INT NOT NULL,
  `sale_item_id` INT DEFAULT NULL,
  `product_id` INT DEFAULT NULL,
  `product_name` VARCHAR(200) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `unit_price` DECIMAL(12,2) NOT NULL,
  `subtotal` DECIMAL(12,2) NOT NULL,
  `restocked` TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_return_items_return` (`return_id`),
  FOREIGN KEY (`return_id`) REFERENCES `returns`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- 4. COLUMNAS DE CRÉDITO PARA VENTAS
ALTER TABLE sales ADD COLUMN IF NOT EXISTS credit_type VARCHAR(20) DEFAULT NULL;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS credit_installments INT DEFAULT NULL;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS credit_frequency VARCHAR(20) DEFAULT NULL;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS due_date DATE DEFAULT NULL;
