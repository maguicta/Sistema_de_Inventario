# Manual de Uso — Sistema de Control de Inventario y Ventas

## Índice

1. [Requisitos del Sistema](#1-requisitos-del-sistema)
2. [Instalación](#2-instalación)
3. [Primer Inicio de Sesión](#3-primer-inicio-de-sesión)
4. [Panel Principal (Dashboard)](#4-panel-principal-dashboard)
5. [Gestión de Productos](#5-gestión-de-productos)
6. [Ventas (POS)](#6-ventas-pos)
7. [Devoluciones y Créditos](#7-devoluciones-y-créditos)
8. [Cotizaciones](#8-cotizaciones)
9. [Órdenes de Compra](#9-órdenes-de-compra)
10. [Gastos](#10-gastos)
11. [Proveedores](#11-proveedores)
12. [Categorías](#12-categorías)
13. [Usuarios](#13-usuarios)
14. [Catálogo Público](#14-catálogo-público)
15. [Promociones](#15-promociones)
16. [Reportes](#16-reportes)
17. [Configuración](#17-configuración)
18. [Cuentas por Cobrar](#18-cuentas-por-cobrar)
19. [Solución de Problemas](#19-solución-de-problemas)

---

## 1. Requisitos del Sistema

-   **Sistema Operativo:** Windows 10 u 11
-   **Node.js:** Versión 18 o superior ([descargar](https://nodejs.org))
-   **MySQL:** 5.7 o superior (se recomienda [XAMPP](https://www.apachefriends.org/) o [WampServer](https://www.wampserver.com/))
-   **Navegador:** Chrome, Firefox o Edge (actualizados)

---

## 2. Instalación

### 2.1 Instalación automática (recomendada)

1.  Asegúrese de tener **Node.js** instalado.
2.  Asegúrese de tener **MySQL** instalado y encendido (abra XAMPP o WampServer y encienda el servicio de MySQL).
3.  Haga **doble clic en `setup.bat`**.
4.  En la ventana que aparece, complete los siguientes datos:
    -   **MySQL:** Host (generalmente `localhost`), Puerto (`3306`), Usuario (`root`), Contraseña (la que tenga configurada en MySQL, puede estar vacía).
    -   **Base de datos:** El nombre que desee para la base de datos (ej: `inventario_db`).
    -   **Administrador:** El correo electrónico y la contraseña que usará para ingresar al sistema.
    -   **Nombre del negocio:** El nombre de su empresa o tienda.
5.  Haga clic en **"Instalar Sistema"**.
6.  Espere a que el proceso termine. Al finalizar, se creará un acceso directo en el escritorio.
7.  Elija si desea iniciar el sistema ahora.

### 2.2 Inicio del sistema

-   **Desde el acceso directo** en el escritorio: haga doble clic en "Sistema de Inventario".
-   **Desde la carpeta** del sistema: haga doble clic en `iniciar_sistema.bat`.
-   **Manual:** Abra una terminal en la carpeta del sistema y ejecute `npm start`.

El sistema se abrirá automáticamente en su navegador en la dirección `http://localhost:3000`.

---

## 3. Primer Inicio de Sesión

1.  En la pantalla de inicio de sesión, ingrese las credenciales que configuró durante la instalación.
2.  Seleccione la sucursal "Sucursal Principal".
3.  Haga clic en **"Iniciar Sesión"**.

> **Nota:** Si olvidó sus credenciales, ejecute el siguiente comando en la carpeta del sistema:
> ```
> node database/reset_admin.js
> ```
> Esto restablecerá el correo a `admin@sistema.com` y la contraseña a `admin123`.

---

## 4. Panel Principal (Dashboard)

El dashboard muestra un resumen general del negocio:

-   **Tarjetas superiores:** Ventas del día, ventas del mes, productos bajos en stock, productos totales.
-   **Gráfico de ventas:** Muestra las ventas de los últimos 7 días.
-   **Gráfico de ingresos vs gastos:** Comparativa mensual.
-   **Productos con stock bajo:** Lista de productos que necesitan reabastecimiento.
-   **Últimas ventas:** Lista de las ventas más recientes.

---

## 5. Gestión de Productos

### 5.1 Agregar un producto

1.  En el menú lateral, vaya a **Inventario > Productos**.
2.  Haga clic en **"Nuevo Producto"**.
3.  Complete los campos:
    -   **Nombre:** Nombre del producto (obligatorio).
    -   **SKU:** Código único de identificación.
    -   **Categoría:** Seleccione una categoría existente.
    -   **Precio:** Precio de venta.
    -   **Costo:** Precio de compra.
    -   **Stock:** Cantidad disponible.
    -   **Stock mínimo:** Cantidad mínima antes de alertar.
    -   **Unidad:** Unidad de medida (unidad, kilo, litro, etc.).
    -   **Proveedor:** Seleccione un proveedor.
    -   **Imagen:** Puede subir una foto del producto.
    -   **Fecha de vencimiento:** Opcional, para productos perecederos.
4.  Haga clic en **"Guardar"**.

### 5.2 Editar o eliminar un producto

-   Use los botones **✏️** (editar) y **🗑️** (eliminar) en la tabla de productos.
-   También puede hacer clic en un producto para ver su detalle.

### 5.3 Búsqueda y filtros

-   Use la barra de **búsqueda** para encontrar productos por nombre o SKU.
-   Use los **filtros** por categoría, estado y sucursal.

### 5.4 Productos por vencer

-   En el menú lateral, vaya a **Inventario > Vencimientos** para ver productos próximos a vencer.

---

## 6. Ventas (POS)

### 6.1 Realizar una venta

1.  En el menú lateral, vaya a **Operaciones > Nueva Venta**.
2.  Busque productos por nombre o SKU y agréguelos al carrito.
3.  Ajuste las cantidades si es necesario.
4.  Ingrese el nombre del cliente (opcional, por defecto "Cliente General").
5.  Seleccione el **método de pago**:
    -   **Efectivo:** Ingrese el monto con el que paga, el sistema calculará el cambio.
    -   **Tarjeta:** Registre el pago con tarjeta.
    -   **Transferencia:** Registre el pago por transferencia.
    -   **Crédito (fiado):** Seleccione esta opción para ventas a crédito. Configure el plazo.
6.  Haga clic en **"Completar Venta"**.

### 6.2 Ticket de venta

Después de completar la venta, se generará un ticket. Puede:
-   **Imprimirlo** en una impresora térmica.
-   **Descargarlo en PDF.**

### 6.3 Historial de ventas

1.  Vaya a **Operaciones > Ventas**.
2.  Vea todas las ventas realizadas, con filtros por fecha y sucursal.
3.  Haga clic en una venta para ver su detalle o imprimir el ticket nuevamente.

---

## 7. Devoluciones y Créditos

### 7.1 Cuentas por Cobrar (Créditos)

1.  Vaya a **Operaciones > Cuentas por Cobrar**.
2.  Vea todas las ventas a crédito pendientes de pago.
3.  Para registrar un abono:
    -   Haga clic en **"Ver Detalle"** en la venta.
    -   En la sección de abonos, haga clic en **"Registrar Abono"**.
    -   Ingrese el monto y el método de pago.

### 7.2 Realizar una devolución

1.  Vaya a **Operaciones > Devoluciones**.
2.  Haga clic en **"Nueva Devolución"**.
3.  Busque la venta por número de factura.
4.  Seleccione los productos a devolver y la cantidad.
5.  Ingrese el motivo de la devolución.
6.  Haga clic en **"Procesar Devolución"**.

> **Nota:** Las devoluciones reingresan el stock automáticamente.

---

## 8. Cotizaciones

### 8.1 Crear una cotización

1.  Vaya a **Operaciones > Cotizaciones**.
2.  Haga clic en **"Nueva Cotización"**.
3.  Agregue productos y ajuste cantidades.
4.  Establezca una fecha de vencimiento para la cotización.
5.  Haga clic en **"Guardar Cotización"**.

### 8.2 Convertir cotización en venta

1.  En la lista de cotizaciones, haga clic en **"Convertir en Venta"** en la cotización deseada.
2.  Esto abre el POS con los productos precargados.

---

## 9. Órdenes de Compra

### 9.1 Crear una orden de compra

1.  Vaya a **Operaciones > Órdenes de Compra**.
2.  Haga clic en **"Nueva Orden"**.
3.  Seleccione un proveedor.
4.  Agregue productos y cantidades.
5.  Complete la orden. El estado inicial es "Pendiente".

### 9.2 Recibir una orden

1.  Cuando llegue la mercancía, abra la orden.
2.  Haga clic en **"Recibir"**.
3.  Los productos se agregarán al stock automáticamente.

### 9.3 Subir factura

Puede subir una imagen o PDF de la factura del proveedor en cada orden de compra.

---

## 10. Gastos

1.  Vaya a **Operaciones > Gastos**.
2.  Haga clic en **"Nuevo Gasto"**.
3.  Seleccione la categoría del gasto (alquiler, servicios, salarios, etc.).
4.  Ingrese el monto y una descripción.
5.  Haga clic en **"Guardar"**.

Los gastos se reflejan automáticamente en los reportes y gráficos del dashboard.

---

## 11. Proveedores

1.  Vaya a **Inventario > Proveedores**.
2.  Haga clic en **"Nuevo Proveedor"**.
3.  Complete los datos: nombre, persona de contacto, correo, teléfono, dirección, RNC/Cédula.
4.  Haga clic en **"Guardar"**.

---

## 12. Categorías

1.  Vaya a **Inventario > Categorías**.
2.  Haga clic en **"Nueva Categoría"**.
3.  Ingrese el nombre, descripción, color y/o icono.
4.  Haga clic en **"Guardar"**.

---

## 13. Usuarios

### 13.1 Crear un usuario

1.  Vaya a **Administración > Usuarios**.
2.  Haga clic en **"Nuevo Usuario"**.
3.  Complete: nombre, correo, contraseña, rol (admin o vendedor), sucursal.
4.  Configure permisos: puede editar, puede eliminar, activo.
5.  Haga clic en **"Guardar"**.

### 13.2 Roles y permisos

-   **Admin:** Acceso completo al sistema.
-   **Vendedor:** Puede vender, ver productos y reportes. Los permisos de editar y eliminar se configuran individualmente.

---

## 14. Catálogo Público

El sistema incluye un catálogo público que puede compartir con sus clientes:

1.  Configure el nombre y logo de su tienda en **Configuración**.
2.  Comparta el enlace: `http://localhost:3000/catalog.html?branch=1`
3.  Los clientes pueden ver productos, precios y promociones.
4.  Pueden consultar por WhatsApp haciendo clic en el botón correspondiente.

---

## 15. Promociones

1.  Vaya a **Administración > Promociones**.
2.  Haga clic en **"Nueva Promoción"**.
3.  Configure:
    -   **Nombre:** Nombre de la promoción.
    -   **Tipo:** Porcentaje (%) o monto fijo (RD$).
    -   **Aplica a:** Todos los productos, por categoría o producto específico.
    -   **Fechas:** Inicio y fin de la promoción.
4.  Haga clic en **"Guardar"**.

Las promociones activas se aplican automáticamente en el POS y en el catálogo público.

---

## 16. Reportes

1.  Vaya a **Administración > Reportes**.
2.  Seleccione el tipo de reporte:
    -   **Ventas por período:** Ventas totales, impuestos, ganancias.
    -   **Productos más vendidos:** Ranking de productos.
    -   **Gastos por categoría:** Resumen de gastos.
    -   **Movimientos de inventario:** Historial de entradas y salidas.

---

## 17. Configuración

1.  Vaya a **Administración > Configuración**.
2.  Puede modificar:
    -   **Nombre de la tienda** (se muestra en toda la aplicación).
    -   **Moneda base** (DOP, USD, etc.).
    -   **Símbolo de moneda** (RD$, $, etc.).
    -   **Tasa de impuesto** (ITBIS: 18% en República Dominicana).
    -   **Tema visual** (Midnight, Light, etc.).
    -   **Stock negativo:** Permitir o no vender sin stock.

---

## 18. Cuentas por Cobrar

1.  Vaya a **Operaciones > Cuentas por Cobrar**.
2.  El panel muestra:
    -   **Total pendiente:** Suma de todas las ventas a crédito no pagadas.
    -   **Resumen:** Abonos realizados, ventas al contado vs crédito.
    -   **Lista de clientes:** Cada venta a crédito con su saldo pendiente.
3.  Para registrar un pago, haga clic en **"Ver Detalle"** y luego en **"Registrar Abono"** en la venta correspondiente.

---

## 19. Solución de Problemas

| Problema | Solución |
|----------|----------|
| "Error de conexión a MySQL" | Asegúrese de que XAMPP o WampServer esté encendido |
| "No se pudo inicializar la base de datos" | Verifique que MySQL esté corriendo en el puerto 3306 |
| "Sesión expirada" | Borre los datos del navegador o cierre sesión y vuelva a ingresar |
| "Credenciales inválidas" | Ejecute `node database/reset_admin.js` para restablecer la contraseña |
| "Error al iniciar el servidor" | Verifique que el puerto 3000 no esté siendo usado por otro programa |
| "No se ven las imágenes" | Verifique que la carpeta `uploads` exista y tenga permisos de escritura |
| "El catálogo no carga" | Verifique que haya productos activos y MySQL esté funcionando |
| No recuerdo mi contraseña | Ejecute `node database/reset_admin.js` en la carpeta del sistema |

### Contacto de soporte

Si necesita ayuda adicional, contacte al desarrollador del sistema.

---

*Documentación generada para el Sistema de Control de Inventario y Ventas*
