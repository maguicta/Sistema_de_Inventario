const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const { authMiddleware } = require('../middleware/auth');

router.use(authMiddleware);

// GET /api/payments/receivables
// Obtiene todas las ventas pendientes (Fiados)
router.get('/receivables', async (req, res) => {
  try {
    const branch_id = req.user.branch_id || 1;
    const [sales] = await pool.query(`
      SELECT s.*, u.name as user_name 
      FROM sales s 
      LEFT JOIN users u ON s.user_id = u.id 
      WHERE s.status = 'pendiente' AND s.branch_id = ?
      ORDER BY s.created_at DESC
    `, [branch_id]);
    res.json(sales);
  } catch (error) {
    console.error('Error fetching receivables:', error);
    res.status(500).json({ error: 'Error al obtener cuentas por cobrar' });
  }
});

// GET /api/payments/:sale_id
// Obtiene los pagos de una venta específica
router.get('/:sale_id', async (req, res) => {
  try {
    const { sale_id } = req.params;
    const branch_id = req.user.branch_id || 1;
    
    // Validar que la venta pertenece a la sucursal
    const [sale] = await pool.query('SELECT id FROM sales WHERE id = ? AND branch_id = ?', [sale_id, branch_id]);
    if (sale.length === 0) {
      return res.status(404).json({ error: 'Venta no encontrada en esta sucursal' });
    }

    const [payments] = await pool.query(`
      SELECT p.*, u.name as user_name 
      FROM sale_payments p
      LEFT JOIN users u ON p.user_id = u.id
      WHERE p.sale_id = ?
      ORDER BY p.created_at ASC
    `, [sale_id]);
    
    res.json(payments);
  } catch (error) {
    console.error('Error fetching payments:', error);
    res.status(500).json({ error: 'Error al obtener abonos' });
  }
});

// POST /api/payments
// Registra un nuevo abono
router.post('/', async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const { sale_id, amount, payment_method } = req.body;
    const branch_id = req.user.branch_id || 1;
    const user_id = req.user.id;

    if (!sale_id || !amount || amount <= 0) {
      return res.status(400).json({ error: 'Datos inválidos para el abono' });
    }

    // Obtener la venta
    const [sales] = await conn.query('SELECT * FROM sales WHERE id = ? AND branch_id = ? FOR UPDATE', [sale_id, branch_id]);
    if (sales.length === 0) throw new Error('Venta no encontrada');
    const sale = sales[0];

    if (sale.status !== 'pendiente') {
      throw new Error('La venta ya está completada o no es un fiado');
    }

    const total = parseFloat(sale.total);
    const amountPaid = parseFloat(sale.amount_paid) || 0;
    const newAmountPaid = amountPaid + parseFloat(amount);

    if (newAmountPaid > total) {
      throw new Error(`El abono supera la deuda restante (${total - amountPaid})`);
    }

    // Registrar el pago
    await conn.query(`
      INSERT INTO sale_payments (sale_id, user_id, amount, payment_method, branch_id)
      VALUES (?, ?, ?, ?, ?)
    `, [sale_id, user_id, amount, payment_method || 'efectivo', branch_id]);

    // Actualizar la venta
    let newStatus = 'pendiente';
    if (newAmountPaid >= total) {
      newStatus = 'completada';
    }

    await conn.query(`
      UPDATE sales SET amount_paid = ?, status = ? WHERE id = ?
    `, [newAmountPaid, newStatus, sale_id]);

    await conn.commit();
    res.json({ message: 'Abono registrado con éxito', status: newStatus, amount_paid: newAmountPaid });

  } catch (error) {
    await conn.rollback();
    console.error('Error processing payment:', error);
    res.status(500).json({ error: error.message || 'Error al procesar el abono' });
  } finally {
    conn.release();
  }
});

module.exports = router;
