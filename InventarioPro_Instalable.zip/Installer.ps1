Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
$projectPath = $scriptPath

$form = New-Object System.Windows.Forms.Form
$form.Text = "Instalador - Sistema de Inventario"
$form.Size = New-Object System.Drawing.Size(520, 620)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.BackColor = "#1a1a2e"

$title = New-Object System.Windows.Forms.Label
$title.Text = "INSTALACIÓN DEL SISTEMA DE INVENTARIO"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = "#e2e8f0"
$title.Size = New-Object System.Drawing.Size(480, 35)
$title.Location = New-Object System.Drawing.Point(20, 15)
$form.Controls.Add($title)

$subtitle = New-Object System.Windows.Forms.Label
$subtitle.Text = "Complete los datos para configurar el sistema"
$subtitle.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$subtitle.ForeColor = "#94a3b8"
$subtitle.Size = New-Object System.Drawing.Size(480, 20)
$subtitle.Location = New-Object System.Drawing.Point(20, 50)
$form.Controls.Add($subtitle)

$sep1 = New-Object System.Windows.Forms.Label
$sep1.Text = "╌" * 55
$sep1.ForeColor = "#334155"
$sep1.Size = New-Object System.Drawing.Size(480, 15)
$sep1.Location = New-Object System.Drawing.Point(20, 72)
$form.Controls.Add($sep1)

$lblMysql = New-Object System.Windows.Forms.Label
$lblMysql.Text = "CONEXIÓN MySQL"
$lblMysql.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$lblMysql.ForeColor = "#818cf8"
$lblMysql.Size = New-Object System.Drawing.Size(480, 20)
$lblMysql.Location = New-Object System.Drawing.Point(20, 90)
$form.Controls.Add($lblMysql)

$lblHost = New-Object System.Windows.Forms.Label
$lblHost.Text = "Host:"
$lblHost.ForeColor = "#cbd5e1"
$lblHost.Size = New-Object System.Drawing.Size(100, 20)
$lblHost.Location = New-Object System.Drawing.Point(20, 115)
$form.Controls.Add($lblHost)

$txtHost = New-Object System.Windows.Forms.TextBox
$txtHost.Text = "localhost"
$txtHost.Size = New-Object System.Drawing.Size(180, 22)
$txtHost.Location = New-Object System.Drawing.Point(90, 113)
$txtHost.BackColor = "#0f172a"
$txtHost.ForeColor = "#e2e8f0"
$txtHost.BorderStyle = "FixedSingle"
$form.Controls.Add($txtHost)

$lblPort = New-Object System.Windows.Forms.Label
$lblPort.Text = "Puerto:"
$lblPort.ForeColor = "#cbd5e1"
$lblPort.Size = New-Object System.Drawing.Size(60, 20)
$lblPort.Location = New-Object System.Drawing.Point(290, 115)
$form.Controls.Add($lblPort)

$txtPort = New-Object System.Windows.Forms.TextBox
$txtPort.Text = "3306"
$txtPort.Size = New-Object System.Drawing.Size(80, 22)
$txtPort.Location = New-Object System.Drawing.Point(345, 113)
$txtPort.BackColor = "#0f172a"
$txtPort.ForeColor = "#e2e8f0"
$txtPort.BorderStyle = "FixedSingle"
$form.Controls.Add($txtPort)

$lblUser = New-Object System.Windows.Forms.Label
$lblUser.Text = "Usuario:"
$lblUser.ForeColor = "#cbd5e1"
$lblUser.Size = New-Object System.Drawing.Size(100, 20)
$lblUser.Location = New-Object System.Drawing.Point(20, 145)
$form.Controls.Add($lblUser)

$txtUser = New-Object System.Windows.Forms.TextBox
$txtUser.Text = "root"
$txtUser.Size = New-Object System.Drawing.Size(180, 22)
$txtUser.Location = New-Object System.Drawing.Point(90, 143)
$txtUser.BackColor = "#0f172a"
$txtUser.ForeColor = "#e2e8f0"
$txtUser.BorderStyle = "FixedSingle"
$form.Controls.Add($txtUser)

$lblPass = New-Object System.Windows.Forms.Label
$lblPass.Text = "Contraseña:"
$lblPass.ForeColor = "#cbd5e1"
$lblPass.Size = New-Object System.Drawing.Size(100, 20)
$lblPass.Location = New-Object System.Drawing.Point(290, 145)
$form.Controls.Add($lblPass)

$txtMysqlPass = New-Object System.Windows.Forms.TextBox
$txtMysqlPass.Text = ""
$txtMysqlPass.PasswordChar = "*"
$txtMysqlPass.Size = New-Object System.Drawing.Size(180, 22)
$txtMysqlPass.Location = New-Object System.Drawing.Point(290, 173)
$txtMysqlPass.BackColor = "#0f172a"
$txtMysqlPass.ForeColor = "#e2e8f0"
$txtMysqlPass.BorderStyle = "FixedSingle"

$lblMysqlPass = New-Object System.Windows.Forms.Label
$lblMysqlPass.Text = "Contraseña MySQL:"
$lblMysqlPass.ForeColor = "#cbd5e1"
$lblMysqlPass.Size = New-Object System.Drawing.Size(120, 20)
$lblMysqlPass.Location = New-Object System.Drawing.Point(20, 175)
$form.Controls.Add($lblMysqlPass)
$form.Controls.Add($txtMysqlPass)

$lblDbName = New-Object System.Windows.Forms.Label
$lblDbName.Text = "Base de datos:"
$lblDbName.ForeColor = "#cbd5e1"
$lblDbName.Size = New-Object System.Drawing.Size(120, 20)
$lblDbName.Location = New-Object System.Drawing.Point(20, 205)
$form.Controls.Add($lblDbName)

$txtDbName = New-Object System.Windows.Forms.TextBox
$txtDbName.Text = "inventario_db"
$txtDbName.Size = New-Object System.Drawing.Size(180, 22)
$txtDbName.Location = New-Object System.Drawing.Point(120, 203)
$txtDbName.BackColor = "#0f172a"
$txtDbName.ForeColor = "#e2e8f0"
$txtDbName.BorderStyle = "FixedSingle"
$form.Controls.Add($txtDbName)

$sep2 = New-Object System.Windows.Forms.Label
$sep2.Text = "╌" * 55
$sep2.ForeColor = "#334155"
$sep2.Size = New-Object System.Drawing.Size(480, 15)
$sep2.Location = New-Object System.Drawing.Point(20, 232)
$form.Controls.Add($sep2)

$lblAdmin = New-Object System.Windows.Forms.Label
$lblAdmin.Text = "CUENTA ADMINISTRADOR"
$lblAdmin.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$lblAdmin.ForeColor = "#34d399"
$lblAdmin.Size = New-Object System.Drawing.Size(480, 20)
$lblAdmin.Location = New-Object System.Drawing.Point(20, 250)
$form.Controls.Add($lblAdmin)

$lblAdminEmail = New-Object System.Windows.Forms.Label
$lblAdminEmail.Text = "Correo electrónico:"
$lblAdminEmail.ForeColor = "#cbd5e1"
$lblAdminEmail.Size = New-Object System.Drawing.Size(140, 20)
$lblAdminEmail.Location = New-Object System.Drawing.Point(20, 275)
$form.Controls.Add($lblAdminEmail)

$txtAdminEmail = New-Object System.Windows.Forms.TextBox
$txtAdminEmail.Text = "admin@sistema.com"
$txtAdminEmail.Size = New-Object System.Drawing.Size(340, 22)
$txtAdminEmail.Location = New-Object System.Drawing.Point(20, 295)
$txtAdminEmail.BackColor = "#0f172a"
$txtAdminEmail.ForeColor = "#e2e8f0"
$txtAdminEmail.BorderStyle = "FixedSingle"
$form.Controls.Add($txtAdminEmail)

$lblAdminPass = New-Object System.Windows.Forms.Label
$lblAdminPass.Text = "Contraseña:"
$lblAdminPass.ForeColor = "#cbd5e1"
$lblAdminPass.Size = New-Object System.Drawing.Size(140, 20)
$lblAdminPass.Location = New-Object System.Drawing.Point(20, 325)
$form.Controls.Add($lblAdminPass)

$txtAdminPass = New-Object System.Windows.Forms.TextBox
$txtAdminPass.Text = ""
$txtAdminPass.PasswordChar = "*"
$txtAdminPass.Size = New-Object System.Drawing.Size(200, 22)
$txtAdminPass.Location = New-Object System.Drawing.Point(20, 345)
$txtAdminPass.BackColor = "#0f172a"
$txtAdminPass.ForeColor = "#e2e8f0"
$txtAdminPass.BorderStyle = "FixedSingle"
$form.Controls.Add($txtAdminPass)

$lblAdminPass2 = New-Object System.Windows.Forms.Label
$lblAdminPass2.Text = "Confirmar contraseña:"
$lblAdminPass2.ForeColor = "#cbd5e1"
$lblAdminPass2.Size = New-Object System.Drawing.Size(140, 20)
$lblAdminPass2.Location = New-Object System.Drawing.Point(240, 325)
$form.Controls.Add($lblAdminPass2)

$txtAdminPass2 = New-Object System.Windows.Forms.TextBox
$txtAdminPass2.Text = ""
$txtAdminPass2.PasswordChar = "*"
$txtAdminPass2.Size = New-Object System.Drawing.Size(220, 22)
$txtAdminPass2.Location = New-Object System.Drawing.Point(240, 345)
$txtAdminPass2.BackColor = "#0f172a"
$txtAdminPass2.ForeColor = "#e2e8f0"
$txtAdminPass2.BorderStyle = "FixedSingle"
$form.Controls.Add($txtAdminPass2)

$lblStoreName = New-Object System.Windows.Forms.Label
$lblStoreName.Text = "Nombre del negocio:"
$lblStoreName.ForeColor = "#cbd5e1"
$lblStoreName.Size = New-Object System.Drawing.Size(140, 20)
$lblStoreName.Location = New-Object System.Drawing.Point(20, 380)
$form.Controls.Add($lblStoreName)

$txtStoreName = New-Object System.Windows.Forms.TextBox
$txtStoreName.Text = "Inventario Pro"
$txtStoreName.Size = New-Object System.Drawing.Size(340, 22)
$txtStoreName.Location = New-Object System.Drawing.Point(20, 400)
$txtStoreName.BackColor = "#0f172a"
$txtStoreName.ForeColor = "#e2e8f0"
$txtStoreName.BorderStyle = "FixedSingle"
$form.Controls.Add($txtStoreName)

$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Size = New-Object System.Drawing.Size(460, 20)
$progressBar.Location = New-Object System.Drawing.Point(20, 440)
$progressBar.Style = "Continuous"
$progressBar.Visible = $false
$form.Controls.Add($progressBar)

$statusLabel = New-Object System.Windows.Forms.Label
$statusLabel.Text = ""
$statusLabel.ForeColor = "#94a3b8"
$statusLabel.Size = New-Object System.Drawing.Size(460, 40)
$statusLabel.Location = New-Object System.Drawing.Point(20, 465)
$statusLabel.TextAlign = "TopLeft"
$form.Controls.Add($statusLabel)

$btnInstall = New-Object System.Windows.Forms.Button
$btnInstall.Text = "INSTALAR SISTEMA"
$btnInstall.Size = New-Object System.Drawing.Size(220, 45)
$btnInstall.Location = New-Object System.Drawing.Point(140, 515)
$btnInstall.BackColor = "#6366f1"
$btnInstall.ForeColor = "White"
$btnInstall.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$btnInstall.FlatStyle = "Flat"
$btnInstall.Cursor = "Hand"
$form.Controls.Add($btnInstall)

function SetStatus($msg, $color) {
    $statusLabel.Text = $msg
    if ($color) { $statusLabel.ForeColor = $color }
    $form.Refresh()
}

function Install {
    $btnInstall.Enabled = $false
    $btnInstall.Text = "INSTALANDO..."
    $progressBar.Visible = $true
    $progressBar.Value = 5

    $adminEmail = $txtAdminEmail.Text.Trim()
    $adminPass = $txtAdminPass.Text
    $adminPass2 = $txtAdminPass2.Text.Trim()
    $dbName = $txtDbName.Text.Trim()
    $storeName = $txtStoreName.Text.Trim()

    if (-not $adminEmail -or $adminEmail -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') {
        SetStatus "ERROR: Correo electrónico inválido" "Red"
        $btnInstall.Enabled = $true; $btnInstall.Text = "INSTALAR SISTEMA"; return
    }
    if ($adminPass.Length -lt 4) {
        SetStatus "ERROR: La contraseña debe tener al menos 4 caracteres" "Red"
        $btnInstall.Enabled = $true; $btnInstall.Text = "INSTALAR SISTEMA"; return
    }
    if ($adminPass -ne $adminPass2) {
        SetStatus "ERROR: Las contraseñas no coinciden" "Red"
        $btnInstall.Enabled = $true; $btnInstall.Text = "INSTALAR SISTEMA"; return
    }
    if (-not $dbName) {
        SetStatus "ERROR: El nombre de la base de datos es requerido" "Red"
        $btnInstall.Enabled = $true; $btnInstall.Text = "INSTALAR SISTEMA"; return
    }
    if (-not $storeName) {
        SetStatus "ERROR: El nombre del negocio es requerido" "Red"
        $btnInstall.Enabled = $true; $btnInstall.Text = "INSTALAR SISTEMA"; return
    }

    try {
        SetStatus "✔ Verificando Node.js..." "#94a3b8"
        $nodeCheck = Get-Command "node" -ErrorAction SilentlyContinue
        if (-not $nodeCheck) {
            SetStatus "ERROR: Node.js no está instalado. Descárguelo de https://nodejs.org" "Red"
            $btnInstall.Enabled = $true; $btnInstall.Text = "INSTALAR SISTEMA"; return
        }
        $nodeVersion = node --version
        SetStatus "✔ Node.js detectado: $nodeVersion" "#34d399"
        $progressBar.Value = 15

        SetStatus "✔ Instalando dependencias del sistema..." "#94a3b8"
        Set-Location -Path $projectPath
        $npmResult = npm install --no-audit --no-fund 2>&1
        if ($LASTEXITCODE -ne 0 -and $LASTEXITCODE -ne $null) {
            SetStatus "ERROR al instalar dependencias de npm. Revise su conexión." "Red"
            $btnInstall.Enabled = $true; $btnInstall.Text = "INSTALAR SISTEMA"; return
        }
        SetStatus "✔ Dependencias instaladas correctamente" "#34d399"
        $progressBar.Value = 35

        SetStatus "✔ Configurando base de datos..." "#94a3b8"
        $envContent = @"
DB_HOST=$($txtHost.Text.Trim())
DB_PORT=$($txtPort.Text.Trim())
DB_USER=$($txtUser.Text.Trim())
DB_PASSWORD=$($txtMysqlPass.Text)
DB_NAME=$dbName
JWT_SECRET=inv_secret_$( -join ((65..90) + (97..122) | Get-Random -Count 20 | % { [char]$_ }) )
PORT=3000
ADMIN_EMAIL=$adminEmail
ADMIN_PASSWORD=$adminPass
"@
        Set-Content -Path "$projectPath\.env" -Value $envContent -Force
        SetStatus "✔ Archivo .env creado" "#34d399"
        $progressBar.Value = 50

        SetStatus "✔ Creando base de datos y tablas..." "#94a3b8"
        $envVars = @{DB_HOST=$txtHost.Text.Trim(); DB_PORT=$txtPort.Text.Trim(); DB_USER=$txtUser.Text.Trim(); DB_PASSWORD=$txtMysqlPass.Text; DB_NAME=$dbName; ADMIN_EMAIL=$adminEmail; ADMIN_PASSWORD=$adminPass; JWT_SECRET="temp"}
        $initResult = & {
            $env:DB_HOST = $txtHost.Text.Trim()
            $env:DB_PORT = $txtPort.Text.Trim()
            $env:DB_USER = $txtUser.Text.Trim()
            $env:DB_PASSWORD = $txtMysqlPass.Text
            $env:DB_NAME = $dbName
            $env:ADMIN_EMAIL = $adminEmail
            $env:ADMIN_PASSWORD = $adminPass
            $env:JWT_SECRET = "temp_secret"
            node "$projectPath\database\init.js" 2>&1
        }
        if ($LASTEXITCODE -ne 0) {
            SetStatus "ERROR: No se pudo conectar a MySQL. Verifique que XAMPP/WampServer esté encendido." "Red"
            $btnInstall.Enabled = $true; $btnInstall.Text = "INSTALAR SISTEMA"; return
        }
        SetStatus "✔ Base de datos creada exitosamente" "#34d399"
        $progressBar.Value = 75

        SetStatus "✔ Actualizando nombre del negocio..." "#94a3b8"
        $updateResult = & {
            $env:DB_HOST = $txtHost.Text.Trim()
            $env:DB_PORT = $txtPort.Text.Trim()
            $env:DB_USER = $txtUser.Text.Trim()
            $env:DB_PASSWORD = $txtMysqlPass.Text
            $env:DB_NAME = $dbName
            $env:JWT_SECRET = "temp_secret"
            node -e "
                require('dotenv').config();
                const mysql = require('mysql2/promise');
                (async () => {
                    const pool = mysql.createPool({ host: '$($txtHost.Text.Trim())', port: $($txtPort.Text.Trim()), user: '$($txtUser.Text.Trim())', password: '$($txtMysqlPass.Text)', database: '$dbName' });
                    await pool.query(\"UPDATE settings SET setting_value = '$storeName' WHERE setting_key = 'store_name'\");
                    console.log('Nombre actualizado');
                    process.exit(0);
                })();
            " 2>&1
        }
        $progressBar.Value = 85

        SetStatus "✔ Creando acceso directo en el escritorio..." "#94a3b8"
        $desktopPath = [Environment]::GetFolderPath("Desktop")
        $shortcutPath = "$desktopPath\Sistema de Inventario.lnk"
        $WScriptShell = New-Object -ComObject WScript.Shell
        $shortcut = $WScriptShell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = "$projectPath\iniciar_sistema.bat"
        $shortcut.WorkingDirectory = "$projectPath"
        $shortcut.Description = "Sistema de Control de Inventario y Ventas"
        $shortcut.Save()
        SetStatus "✔ Acceso directo creado en el escritorio" "#34d399"
        $progressBar.Value = 95

        SetStatus "✔ Instalación completada exitosamente" "#34d399"

        $result = [System.Windows.Forms.MessageBox]::Show(
            "INSTALACIÓN COMPLETADA`n`nSistema listo para usar.`nAcceso directo creado en el escritorio.`n`n¿Desea iniciar el sistema ahora?",
            "Instalación Exitosa",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Information
        )

        if ($result -eq "Yes") {
            Start-Process -FilePath "$projectPath\iniciar_sistema.bat"
        }

        $form.Close()
    }
    catch {
        SetStatus "ERROR: $_" "Red"
        $btnInstall.Enabled = $true
        $btnInstall.Text = "INSTALAR SISTEMA"
    }
}

$btnInstall.Add_Click({ Install })

$form.ShowDialog()
