const pool = require('./config/database');

async function migrate() {
    try {
        const tables = ['users', 'sales', 'purchase_orders', 'quotes', 'expenses'];
        for (const table of tables) {
            try {
                await pool.query(`ALTER TABLE ${table} ADD COLUMN branch_id INT NOT NULL DEFAULT 1`);
                console.log(`Added branch_id to ${table}`);
            } catch (err) {
                if (err.code === 'ER_DUP_FIELDNAME') {
                    console.log(`branch_id already exists in ${table}`);
                } else {
                    console.error(`Error adding to ${table}:`, err.message);
                }
            }
        }
        console.log('Migration complete.');
        process.exit(0);
    } catch(e) {
        console.error(e);
        process.exit(1);
    }
}

migrate();
