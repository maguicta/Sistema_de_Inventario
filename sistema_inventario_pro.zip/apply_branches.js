const pool = require('./config/database');

async function applyBranches() {
  try {
    await pool.query(`CREATE TABLE IF NOT EXISTS branches (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    const [rows] = await pool.query('SELECT COUNT(*) as c FROM branches');
    if (rows[0].c === 0) {
       await pool.query(`INSERT INTO branches (name) VALUES ('Sede Principal'), ('Sucursal Norte')`);
    }

    // Add branch_id to users
    try { await pool.query(`ALTER TABLE users ADD COLUMN branch_id INT DEFAULT 1;`); } catch(e){}
    try { await pool.query(`ALTER TABLE products ADD COLUMN branch_id INT DEFAULT 1;`); } catch(e){}
    try { await pool.query(`ALTER TABLE sales ADD COLUMN branch_id INT DEFAULT 1;`); } catch(e){}
    try { await pool.query(`ALTER TABLE inventory_movements ADD COLUMN branch_id INT DEFAULT 1;`); } catch(e){}

    console.log('Branches applied successfully!');
    process.exit(0);
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
}

applyBranches();
